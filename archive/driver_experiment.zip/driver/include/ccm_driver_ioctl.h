#pragma once

/*
  Shared IOCTL interface for the CCM telemetry driver.
  This header is intended to be used by:
  - Kernel driver project (KMDF)
  - User-mode bridge/service (future)

  Design constraints:
  - Read-only IOCTLs only.
  - Fixed-size output structs.
  - No “arbitrary read/write” primitives.
*/

#if defined(_KERNEL_MODE) || defined(_NTDDK_) || defined(_KERNEL)
/* Avoid pulling in user-mode CRT headers in kernel builds. */
typedef unsigned __int8  uint8_t;
typedef unsigned __int16 uint16_t;
typedef unsigned __int32 uint32_t;
typedef unsigned __int64 uint64_t;
#else
#include <stdint.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* Device symbolic link used by the driver (user-mode opens \\.\CCMTelemetry). */
#define CCM_DRIVER_DOS_DEVICE_NAME_A "\\\\.\\CCMTelemetry"
#define CCM_DRIVER_NT_DEVICE_NAME_W  L"\\Device\\CCMTelemetry"
#define CCM_DRIVER_DOS_SYMBOLIC_W    L"\\DosDevices\\CCMTelemetry"

/* IOCTL base.
   NOTE: FILE_DEVICE_UNKNOWN is typical for custom telemetry drivers.
*/
#ifndef FILE_DEVICE_UNKNOWN
#define FILE_DEVICE_UNKNOWN 0x00000022
#endif

#ifndef METHOD_BUFFERED
#define METHOD_BUFFERED 0
#endif

#ifndef FILE_READ_DATA
#define FILE_READ_DATA 0x0001
#endif

#ifndef CTL_CODE
#define CTL_CODE(DeviceType, Function, Method, Access) ( \
  ((DeviceType) << 16) | ((Access) << 14) | ((Function) << 2) | (Method) )
#endif

/* Public versioning.
   - ABI increments on breaking struct/semantic changes.
*/
#define CCM_DRIVER_VERSION_MAJOR 0u
#define CCM_DRIVER_VERSION_MINOR 1u
#define CCM_DRIVER_VERSION_PATCH 0u
#define CCM_DRIVER_ABI           1u

typedef struct CCM_DRIVER_VERSION {
    uint32_t major;
    uint32_t minor;
    uint32_t patch;
    uint32_t abi;
} CCM_DRIVER_VERSION;

/* Capability bits are a forward-compat contract.
   The driver returns what it supports on THIS machine/build.
*/
enum {
    CCM_CAP_NONE = 0u,

    /* Future (not implemented yet): */
    CCM_CAP_RDMSR_ALLOWLIST = 1u << 0, /* allow-listed RDMSR */
    CCM_CAP_PCI_CFG_READ    = 1u << 1, /* allow-listed PCI config reads */
    CCM_CAP_ACPI_EC_READ    = 1u << 2, /* EC/ACPI read broker (high risk) */
};

typedef struct CCM_DRIVER_CAPS {
    uint32_t capabilityBits;
} CCM_DRIVER_CAPS;

/* IOCTL function codes (start low, keep stable). */
#define CCM_IOCTL_GET_VERSION CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, FILE_READ_DATA)
#define CCM_IOCTL_GET_CAPS    CTL_CODE(FILE_DEVICE_UNKNOWN, 0x801, METHOD_BUFFERED, FILE_READ_DATA)

#ifdef __cplusplus
}
#endif
