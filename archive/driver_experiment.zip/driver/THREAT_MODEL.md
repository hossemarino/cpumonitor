# CCM telemetry driver – threat model & IOCTL rules (dev)

This document is **developer-facing**. It defines the safety bar for CCM’s optional kernel driver and the user-mode service that brokers access.

## Security goals

- **No dangerous primitives** exposed to user mode.
- **No writes to hardware** (no fan control, no voltages, no OC, no firmware changes).
- **Fail closed**: if the request is not explicitly allowed, it is rejected.
- **Small attack surface**: minimal IOCTL set, minimal parsing, fixed-size structs.
- **Least privilege**: normal users should not be able to talk to the driver.

## Trust boundaries

- **CCM UI (user-mode app)**: untrusted input surface (it can be compromised like any app).
- **Provider/service (user-mode, LocalSystem)**: trusted component that mediates requests; still hardened.
- **Kernel driver (KMDF)**: highest privilege; must be tiny and audited.

**Rule:** CCM UI must never open the driver device directly. The driver is for a LocalSystem service only.

## Attacker model

Assume an attacker can:
- Run arbitrary code as a normal user.
- Try to open the device and send IOCTLs.
- Fuzz IOCTLs with malformed buffers, sizes, and concurrency.
- Attempt denial-of-service (high rate IOCTL spam).

Assume the attacker cannot (by default):
- Bypass kernel-mode code signing policy.
- Load an arbitrary kernel driver (we do not rely on this, but it’s the baseline).

## Device access control

- The driver device object must have a strict ACL (SDDL) such that **only SYSTEM and Administrators** can open it.
- In production, prefer **SYSTEM-only** and make the broker service the only client.

Current SDDL (skeleton):
- `D:P(A;;GA;;;SY)(A;;GA;;;BA)`

## IOCTL design rules (non-negotiable)

### 1) Read-only only

- Only `METHOD_BUFFERED` and only output structs.
- No IOCTL should ever accept pointers/addresses.
- No IOCTL should implement write operations.

### 2) Fixed-size, versioned structs

- Every output struct is fixed-size and fully initialized.
- Add a stable version/ABI handshake via `GET_VERSION` + capability bits.

### 3) Allow-lists everywhere

If an IOCTL can reference a “thing” (MSR index, PCI BDF/offset, EC address), then:
- The driver must validate it against a **hardcoded allow-list**.
- The allow-list is part of the driver build (not user-provided).

### 4) No arbitrary read primitives

Explicitly forbidden patterns:
- “Read physical memory at address X.”
- “Read MMIO at BAR + offset” (unless the BAR/device is allow-listed and offsets are allow-listed).
- `MmMapIoSpace*` for arbitrary addresses.
- `__outbyte/__outword/__outdword`, port writes.
- MSR writes (`WRMSR`) of any kind.

### 5) Strict buffer validation

- Reject requests if output buffer is smaller than required struct size.
- Reject unknown IOCTLs.
- Never trust user-provided lengths; use KMDF helpers and check sizes.
- Always complete requests with explicit `Information` bytes written.

### 6) Rate limiting / DoS resistance

- Implement conservative rate limiting in the service (preferred), and optionally in the driver.
- Driver must never block waiting on hardware for “too long”. If a read can hang, it must have a timeout strategy or be disallowed.

### 7) No information leaks

- Do not return uninitialized stack/heap.
- Do not return kernel pointers.
- Do not expose raw firmware blobs or large buffers.

### 8) Logging

- Keep driver logging minimal; use WPP/ETW tracing if needed.
- Avoid logging untrusted input verbatim.

## Proposed IOCTL categories (future)

These categories are only allowed if they follow the rules above.

### A) RDMSR allow-list

- Request struct: `{ uint32_t msrIndex; uint32_t reserved; }`
- Validation: `msrIndex` must be in an allow-list.
- Output struct: `{ uint32_t msrIndex; uint32_t status; uint64_t value; uint64_t qpc; }`
- AMD-first note: MSRs are useful for counters/time/frequency; many “sensor” values are firmware-mediated.

### B) PCI config read allow-list

- Request: `{ uint16_t seg; uint8_t bus, dev, func; uint16_t offset; uint8_t width; uint8_t reserved; }`
- Validation:
  - (bus,dev,func) must match allow-listed devices.
  - offset/width must be allow-listed and aligned.
- Output: `{ ... value32; status; }`

### C) EC/SMBus

- Highest risk; do last.
- Must be extremely constrained (specific EC addresses only; timeouts; conservative polling).

## Testing requirements

- Build fuzz harness in the service (user-mode) that exercises IOCTLs with boundary conditions.
- Run Driver Verifier (targeted settings) during development.
- Validate with Secure Boot/VBS/HVCI configurations (expect “won’t load” in some configs and document it).

## Definition of done (safety)

Before adding any new IOCTL:
- Update this doc with the exact allow-list and validation logic.
- Add a test tool in user-mode to query the new IOCTL.
- Code review focused on: input validation, allow-list correctness, and “no writes”.
