#include <ntddk.h>
#include <wdf.h>

#include "../include/ccm_driver_ioctl.h"

DRIVER_INITIALIZE DriverEntry;
EVT_WDF_DRIVER_DEVICE_ADD CcmEvtDeviceAdd;

static NTSTATUS CcmCreateDevice(_In_ WDFDRIVER driver, _Inout_ PWDFDEVICE_INIT deviceInit);
static VOID CcmEvtIoDeviceControl(
    _In_ WDFQUEUE queue,
    _In_ WDFREQUEST request,
    _In_ size_t outputBufferLength,
    _In_ size_t inputBufferLength,
    _In_ ULONG ioControlCode);

static const UNICODE_STRING gNtDeviceName = RTL_CONSTANT_STRING(CCM_DRIVER_NT_DEVICE_NAME_W);
static const UNICODE_STRING gDosSymLink   = RTL_CONSTANT_STRING(CCM_DRIVER_DOS_SYMBOLIC_W);

/*
  Strict access control list (ACL):
  - SYSTEM: full access
  - Built-in Administrators: full access

  This intentionally does NOT allow normal users to open the device.
  A future user-mode service can run as LocalSystem and broker reads.
*/
static const wchar_t *gDeviceSddl = L"D:P(A;;GA;;;SY)(A;;GA;;;BA)";

NTSTATUS
DriverEntry(_In_ PDRIVER_OBJECT driverObject, _In_ PUNICODE_STRING registryPath)
{
    WDF_DRIVER_CONFIG config;
    NTSTATUS status;

    WDF_DRIVER_CONFIG_INIT(&config, CcmEvtDeviceAdd);

    status = WdfDriverCreate(driverObject, registryPath, WDF_NO_OBJECT_ATTRIBUTES, &config, WDF_NO_HANDLE);
    return status;
}

NTSTATUS
CcmEvtDeviceAdd(_In_ WDFDRIVER driver, _Inout_ PWDFDEVICE_INIT deviceInit)
{
    return CcmCreateDevice(driver, deviceInit);
}

static NTSTATUS
CcmCreateDevice(_In_ WDFDRIVER driver, _Inout_ PWDFDEVICE_INIT deviceInit)
{
    (void)driver;

    NTSTATUS status;
    WDFDEVICE device;
    WDF_OBJECT_ATTRIBUTES deviceAttributes;
    WDF_IO_QUEUE_CONFIG queueConfig;
    UNICODE_STRING sddl;

    /* Name the device object so user-mode can open \\.\CCMTelemetry via a DOS symbolic link. */
    status = WdfDeviceInitAssignName(deviceInit, &gNtDeviceName);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    /* Apply strict device ACL. */
    RtlInitUnicodeString(&sddl, gDeviceSddl);
    status = WdfDeviceInitAssignSDDLString(deviceInit, &sddl);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    WDF_OBJECT_ATTRIBUTES_INIT(&deviceAttributes);
    status = WdfDeviceCreate(&deviceInit, &deviceAttributes, &device);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    status = WdfDeviceCreateSymbolicLink(device, &gDosSymLink);
    if (!NT_SUCCESS(status)) {
        return status;
    }

    WDF_IO_QUEUE_CONFIG_INIT_DEFAULT_QUEUE(&queueConfig, WdfIoQueueDispatchSequential);
    queueConfig.EvtIoDeviceControl = CcmEvtIoDeviceControl;

    status = WdfIoQueueCreate(device, &queueConfig, WDF_NO_OBJECT_ATTRIBUTES, WDF_NO_HANDLE);
    return status;
}

static VOID
CcmCompleteRequest(_In_ WDFREQUEST request, _In_ NTSTATUS status, _In_ size_t information)
{
    WdfRequestCompleteWithInformation(request, status, information);
}

static VOID
CcmEvtIoDeviceControl(
    _In_ WDFQUEUE queue,
    _In_ WDFREQUEST request,
    _In_ size_t outputBufferLength,
    _In_ size_t inputBufferLength,
    _In_ ULONG ioControlCode)
{
    (void)queue;
    (void)inputBufferLength;

    NTSTATUS status = STATUS_INVALID_DEVICE_REQUEST;

    if (ioControlCode == CCM_IOCTL_GET_VERSION) {
        CCM_DRIVER_VERSION *out = NULL;
        size_t outSize = 0;

        status = WdfRequestRetrieveOutputBuffer(request, sizeof(*out), (PVOID *)&out, &outSize);
        if (NT_SUCCESS(status)) {
            out->major = CCM_DRIVER_VERSION_MAJOR;
            out->minor = CCM_DRIVER_VERSION_MINOR;
            out->patch = CCM_DRIVER_VERSION_PATCH;
            out->abi   = CCM_DRIVER_ABI;
            CcmCompleteRequest(request, STATUS_SUCCESS, sizeof(*out));
            return;
        }
    } else if (ioControlCode == CCM_IOCTL_GET_CAPS) {
        CCM_DRIVER_CAPS *out = NULL;
        size_t outSize = 0;

        status = WdfRequestRetrieveOutputBuffer(request, sizeof(*out), (PVOID *)&out, &outSize);
        if (NT_SUCCESS(status)) {
            out->capabilityBits = CCM_CAP_NONE;
            CcmCompleteRequest(request, STATUS_SUCCESS, sizeof(*out));
            return;
        }
    } else {
        status = STATUS_INVALID_DEVICE_REQUEST;
    }

    /* If we get here, either IOCTL unknown or buffer too small. */
    if (status == STATUS_BUFFER_TOO_SMALL || status == STATUS_BUFFER_OVERFLOW) {
        CcmCompleteRequest(request, status, 0);
        return;
    }

    if (outputBufferLength == 0) {
        /* Keep behavior simple; do not leak kernel info. */
    }

    CcmCompleteRequest(request, status, 0);
}
