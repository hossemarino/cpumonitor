# CCM telemetry driver (KMDF, dev-first)

This folder contains a **minimal read-only** KMDF driver skeleton for CCM.

What it does today:
- Exposes a device `\\.\\CCMTelemetry`
- Accepts two **read-only** IOCTLs:
  - `CCM_IOCTL_GET_VERSION`
  - `CCM_IOCTL_GET_CAPS`

What it explicitly does **not** do (yet):
- No MSR reads
- No PCI config reads
- No EC/SMBus access
- No writes of any kind

## Prerequisites

- Visual Studio 2022 with:
  - “Desktop development with C++”
  - Windows 10/11 SDK
- Windows Driver Kit (WDK) for Windows 10/11 (KMDF)

## Build (PowerShell)

From repo root:

- `pwsh -NoProfile -ExecutionPolicy Bypass -File .\driver\scripts\build_driver.ps1 -Config Release`

## Make a CAT (Inf2Cat)

- `pwsh -NoProfile -ExecutionPolicy Bypass -File .\driver\scripts\make_cat.ps1 -Config Release`

## Test-sign (dev only)

- `pwsh -NoProfile -ExecutionPolicy Bypass -File .\driver\scripts\sign_driver.ps1 -Config Release`
- Offline (no timestamp): `pwsh -NoProfile -ExecutionPolicy Bypass -File .\driver\scripts\sign_driver.ps1 -Config Release -NoTimestamp`

Notes:
- Test-signed kernel drivers typically require **test mode**:
  - `bcdedit /set testsigning on` then reboot.
- On many systems with Secure Boot/HVCI/VBS, loading custom drivers may be blocked.
- Generating/trusting the dev test cert uses the LocalMachine certificate stores and requires an elevated (Admin) PowerShell.

## Install (dev)

Admin PowerShell:

- `pwsh -NoProfile -ExecutionPolicy Bypass -File .\driver\scripts\install_driver.ps1 -Config Release`

If `pnputil` install is flaky on your setup, there is a dev-only fallback that loads the driver as a legacy kernel service:

- Install (Admin): `pwsh -NoProfile -ExecutionPolicy Bypass -File .\driver\scripts\install_legacy_service.ps1 -Config Release`
- Uninstall (Admin): `pwsh -NoProfile -ExecutionPolicy Bypass -File .\driver\scripts\uninstall_legacy_service.ps1`

## Verify (dev)

1) Check driver service:
- `sc.exe query ccm_kmdf`

2) Build and run the user-mode probe (Admin recommended):
- Build: `pwsh -NoProfile -ExecutionPolicy Bypass -File .\driver\scripts\build_probe.ps1 -Config Release`
- Run: `./driver/build/Release/ccm_driver_probe.exe`

## Security model

See `THREAT_MODEL.md` for IOCTL rules, allow-lists, and DoS constraints.

The device object is created with a strict SDDL:
- SYSTEM + Built-in Administrators only

Future plan:
- Run a LocalSystem service that talks to the driver and provides sensor data to CCM over the named pipe provider protocol.
