param(
    [ValidateSet('Debug','Release')]
    [string]$Config = 'Release',

    [string]$CertSubject = 'CN=CCM Telemetry Dev Test',

    # Optional RFC3161 timestamp URL. For dev/test signing this is usually not required.
    [string]$TimestampUrl = 'http://timestamp.digicert.com',

    # Skip timestamping entirely (useful on offline machines).
    [switch]$NoTimestamp,

    # Optional: path to an existing PFX to use instead of generating a new one.
    [string]$PfxPath = ''
)

$ErrorActionPreference = 'Stop'

$pf86 = ${env:ProgramFiles(x86)}

$driverRoot = Split-Path -Parent $PSScriptRoot
$pkgDir = Join-Path $driverRoot ("build\\$Config\\package")

if (!(Test-Path $pkgDir)) {
    throw "Package dir not found ($pkgDir). Run .\\scripts\\make_cat.ps1 first."
}

function Find-SignTool {
    $kitRoot = "$pf86\Windows Kits\10\bin"
    if (Test-Path $kitRoot) {
        $verDirs = Get-ChildItem -Path $kitRoot -Directory -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match '^\d+\.\d+\.\d+\.\d+$' } |
            Sort-Object Name -Descending

        $c = $verDirs |
            ForEach-Object { Join-Path $_.FullName 'x64\signtool.exe' } |
            Where-Object { Test-Path $_ } |
            Select-Object -First 1
        if ($c) { return $c }

        $c = $verDirs |
            ForEach-Object { Join-Path $_.FullName 'x86\signtool.exe' } |
            Where-Object { Test-Path $_ } |
            Select-Object -First 1
        if ($c) { return $c }
    }

    $candidates = @(
        "$pf86\Windows Kits\10\bin\x64\signtool.exe",
        "$pf86\Windows Kits\10\bin\x86\signtool.exe",
        "$pf86\Windows Kits\10\bin\10.0.22621.0\x64\signtool.exe",
        "$pf86\Windows Kits\10\bin\10.0.22621.0\x86\signtool.exe",
        "$pf86\Windows Kits\10\bin\10.0.22000.0\x64\signtool.exe"
        ,
        "$pf86\Windows Kits\10\bin\10.0.22000.0\x86\signtool.exe"
    )
    foreach ($p in $candidates) {
        if (Test-Path $p) { return $p }
    }
    $signtool = (Get-Command signtool.exe -ErrorAction SilentlyContinue)?.Source
    if ($signtool) { return $signtool }
    throw "signtool.exe not found. Install Windows SDK/WDK." 
}

$signtoolExe = Find-SignTool

function Test-IsAdmin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if ([string]::IsNullOrWhiteSpace($PfxPath)) {
    if (-not (Test-IsAdmin)) {
        throw "Generating and trusting a LocalMachine test certificate requires an elevated (Admin) PowerShell. Re-run as Administrator, or pass -PfxPath to use an existing cert."
    }

    Write-Host "Generating a dev test code-signing certificate in LocalMachine\\My: $CertSubject" -ForegroundColor Cyan

    # Create a test certificate suitable for kernel-mode test signing workflows.
    $cert = New-SelfSignedCertificate `
        -Type CodeSigningCert `
        -Subject $CertSubject `
        -CertStoreLocation 'Cert:\LocalMachine\My' `
        -KeyExportPolicy Exportable `
        -KeyLength 2048 `
        -HashAlgorithm SHA256 `
        -NotAfter (Get-Date).AddYears(5)

    # Trust it locally (dev only).
    $cerPath = Join-Path $pkgDir 'ccm-dev-test.cer'
    Export-Certificate -Cert $cert -FilePath $cerPath | Out-Null

    Import-Certificate -FilePath $cerPath -CertStoreLocation 'Cert:\LocalMachine\TrustedPublisher' | Out-Null
    Import-Certificate -FilePath $cerPath -CertStoreLocation 'Cert:\LocalMachine\Root' | Out-Null

    Write-Host "Using cert thumbprint: $($cert.Thumbprint)" -ForegroundColor Cyan
    # /sm = LocalMachine store, /s My = Personal store
    $certArg = @('/sha1', $cert.Thumbprint, '/sm', '/s', 'My')
} else {
    if (!(Test-Path $PfxPath)) { throw "PFX not found: $PfxPath" }
    $pwd = Read-Host -AsSecureString "PFX password"
    $certArg = @('/f', $PfxPath, '/p', (New-Object System.Net.NetworkCredential('', $pwd)).Password)
}

$targets = @(
    (Join-Path $pkgDir 'ccm_kmdf.sys'),
    (Join-Path $pkgDir 'ccm_kmdf.cat')
)

foreach ($t in $targets) {
    if (!(Test-Path $t)) { throw "Missing file to sign: $t" }
}

Write-Host "Signing SYS and CAT in $pkgDir" -ForegroundColor Cyan
foreach ($t in $targets) {
    if ($NoTimestamp -or [string]::IsNullOrWhiteSpace($TimestampUrl)) {
        & $signtoolExe sign @certArg /fd SHA256 $t
    } else {
        & $signtoolExe sign @certArg /fd SHA256 /tr $TimestampUrl /td SHA256 $t
    }
}

Write-Host "Signed. DEV NOTE: for test-signed drivers you typically must enable test mode (bcdedit /set testsigning on) and reboot." -ForegroundColor Yellow
