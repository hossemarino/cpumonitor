param(
    [ValidateSet('Debug','Release')]
    [string]$Config = 'Release',

    [string]$ServiceName = 'ccm_kmdf'
)

$ErrorActionPreference = 'Stop'

$driverRoot = Split-Path -Parent $PSScriptRoot
$pkgDir = Join-Path $driverRoot ("build\\$Config\\package")
$sysSrc = Join-Path $pkgDir 'ccm_kmdf.sys'

if (!(Test-Path $sysSrc)) {
    throw "Signed SYS not found at $sysSrc. Run build -> make_cat -> sign first."
}

$sysDst = Join-Path $env:WINDIR ("System32\\drivers\\$ServiceName.sys")

Write-Host "Installing legacy kernel service '$ServiceName'" -ForegroundColor Cyan
Write-Host "Copying: $sysSrc -> $sysDst" -ForegroundColor Cyan
Copy-Item -Force $sysSrc $sysDst

# If it already exists, delete so we can re-create with correct binPath.
& sc.exe query $ServiceName | Out-Null
if ($LASTEXITCODE -eq 0) {
    Write-Host "Service already exists; stopping + deleting (best-effort)..." -ForegroundColor Yellow
    & sc.exe stop $ServiceName | Out-Null
    & sc.exe delete $ServiceName | Out-Null
    Start-Sleep -Milliseconds 500
}

$binPath = "\\SystemRoot\\System32\\drivers\\$ServiceName.sys"
& sc.exe create $ServiceName type= kernel start= demand error= normal binPath= $binPath

Write-Host "Starting service..." -ForegroundColor Cyan
& sc.exe start $ServiceName

Write-Host "Service status:" -ForegroundColor Cyan
& sc.exe query $ServiceName

Write-Host "Next: run probe (Admin): .\\driver\\build\\Release\\ccm_driver_probe.exe" -ForegroundColor Green
