$ErrorActionPreference = 'Stop'

Write-Host "CCM driver status" -ForegroundColor Cyan

Write-Host "\nService (ccm_kmdf):" -ForegroundColor Cyan
& sc.exe query ccm_kmdf
if ($LASTEXITCODE -ne 0) {
    Write-Host "\nService not found. If you installed via pnputil, list drivers and look for CCM:" -ForegroundColor Yellow
    Write-Host "  pnputil.exe /enum-drivers" -ForegroundColor Yellow
    exit 1
}

Write-Host "\nIf the service is STOPPED, try starting it (Admin):" -ForegroundColor Yellow
Write-Host "  sc.exe start ccm_kmdf" -ForegroundColor Yellow

Write-Host "\nProbe:" -ForegroundColor Cyan
Write-Host "  .\\driver\\build\\Release\\ccm_driver_probe.exe" -ForegroundColor Cyan
