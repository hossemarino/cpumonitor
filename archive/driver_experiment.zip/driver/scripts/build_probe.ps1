param(
    [ValidateSet('x64')]
    [string]$Platform = 'x64',

    [ValidateSet('Debug','Release')]
    [string]$Config = 'Release'
)

$ErrorActionPreference = 'Stop'

$driverRoot = Split-Path -Parent $PSScriptRoot
$src = Join-Path $driverRoot 'probe\ccm_driver_probe.c'
$outDir = Join-Path $driverRoot ('build\' + $Config)
$outExe = Join-Path $outDir 'ccm_driver_probe.exe'

New-Item -ItemType Directory -Force -Path $outDir | Out-Null

$vsDevCmd = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat'
if (!(Test-Path $vsDevCmd)) {
    throw "VsDevCmd.bat not found at $vsDevCmd. Install VS 2022 Build Tools."
}

# Compile with cl.exe inside VsDevCmd environment.
$clArgs = @(
    'cl.exe',
    '/nologo',
    '/W4',
    '/WX',
    '/DUNICODE',
    '/D_UNICODE',
    '/Fe:' + ('"' + $outExe + '"'),
    ('"' + $src + '"')
) -join ' '

$cmdLine = '"' + $vsDevCmd + '" -no_logo -arch=' + $Platform + ' -host_arch=' + $Platform + ' && ' + $clArgs

Write-Host "Building probe -> $outExe" -ForegroundColor Cyan
& cmd.exe /c $cmdLine
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "Built: $outExe" -ForegroundColor Green
