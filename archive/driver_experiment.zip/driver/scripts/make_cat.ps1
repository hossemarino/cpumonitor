param(
    [ValidateSet('Debug','Release')]
    [string]$Config = 'Release'
)

$ErrorActionPreference = 'Stop'

$driverRoot = Split-Path -Parent $PSScriptRoot
$projDir = Join-Path $driverRoot 'ccm_kmdf'
$outDir  = Join-Path $driverRoot ('build\' + $Config)

New-Item -ItemType Directory -Force -Path $outDir | Out-Null

$infPath = Join-Path $projDir 'ccm_kmdf.inf'

$pf86 = ${env:ProgramFiles(x86)}

function Find-Inf2Cat {
    $vswhere = "$pf86\Microsoft Visual Studio\Installer\vswhere.exe"
    if (Test-Path $vswhere) {
        # WDK tools are often installed under Windows Kits; this is a best-effort hint.
        $kitRoot = "$pf86\Windows Kits\10\bin"
        if (Test-Path $kitRoot) {
            $dirs = Get-ChildItem -Path $kitRoot -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending

            $c = $dirs |
                ForEach-Object { Join-Path $_.FullName 'x64\Inf2Cat.exe' } |
                Where-Object { Test-Path $_ } |
                Select-Object -First 1
            if ($c) { return $c }

            # Some installs only ship the x86 Inf2Cat.
            $c = $dirs |
                ForEach-Object { Join-Path $_.FullName 'x86\Inf2Cat.exe' } |
                Where-Object { Test-Path $_ } |
                Select-Object -First 1
            if ($c) { return $c }
        }
    }

    $kits = @(
        "$pf86\Windows Kits\10\bin\x64\Inf2Cat.exe",
        "$pf86\Windows Kits\10\bin\x86\Inf2Cat.exe",
        "$pf86\Windows Kits\10\bin\10.0.22621.0\x64\Inf2Cat.exe",
        "$pf86\Windows Kits\10\bin\10.0.22621.0\x86\Inf2Cat.exe",
        "$pf86\Windows Kits\10\bin\10.0.22000.0\x64\Inf2Cat.exe"
        ,
        "$pf86\Windows Kits\10\bin\10.0.22000.0\x86\Inf2Cat.exe"
    )
    foreach ($p in $kits) {
        if (Test-Path $p) { return $p }
    }
    $inf2cat = (Get-Command Inf2Cat.exe -ErrorAction SilentlyContinue)?.Source
    if ($inf2cat) { return $inf2cat }
    throw "Inf2Cat.exe not found. Install Windows 10/11 WDK (and Windows SDK)."
}

$inf2catExe = Find-Inf2Cat

# Inf2Cat expects the INF to be in the package directory with the SYS.
# We'll stage a tiny package folder.
$pkgDir = Join-Path $outDir 'package'
New-Item -ItemType Directory -Force -Path $pkgDir | Out-Null

Copy-Item -Force $infPath (Join-Path $pkgDir 'ccm_kmdf.inf')

# Copy the built SYS from the MSBuild output.
# Common path: ccm_kmdf\x64\Release\ccm_kmdf.sys
$sysCandidate = Join-Path $projDir ("x64\\$Config\\ccm_kmdf.sys")
if (!(Test-Path $sysCandidate)) {
    throw "Built SYS not found at $sysCandidate. Build first: .\\scripts\\build_driver.ps1 -Config $Config"
}
Copy-Item -Force $sysCandidate (Join-Path $pkgDir 'ccm_kmdf.sys')

Write-Host "Generating CAT in: $pkgDir" -ForegroundColor Cyan
& $inf2catExe /driver:$pkgDir /os:10_X64

Write-Host "CAT generation complete." -ForegroundColor Green
