param(
    [string]$PublishedName = ''
)

$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($PublishedName)) {
    Write-Host "List installed OEM INFs and find the CCM entry:" -ForegroundColor Yellow
    Write-Host "  pnputil.exe /enum-drivers" -ForegroundColor Yellow
    Write-Host "Then rerun: .\\scripts\\uninstall_driver.ps1 -PublishedName oemXX.inf" -ForegroundColor Yellow
    exit 1
}

Write-Host "Uninstalling driver package: $PublishedName" -ForegroundColor Cyan
& pnputil.exe /delete-driver $PublishedName /uninstall /force
