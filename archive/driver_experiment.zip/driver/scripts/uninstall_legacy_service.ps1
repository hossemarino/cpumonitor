param(
    [string]$ServiceName = 'ccm_kmdf'
)

$ErrorActionPreference = 'Stop'

Write-Host "Uninstalling legacy kernel service '$ServiceName'" -ForegroundColor Cyan

& sc.exe stop $ServiceName
& sc.exe delete $ServiceName

$sysDst = Join-Path $env:WINDIR ("System32\\drivers\\$ServiceName.sys")
if (Test-Path $sysDst) {
    Write-Host "Removing $sysDst" -ForegroundColor Cyan
    Remove-Item -Force $sysDst
}

Write-Host "Done." -ForegroundColor Green
