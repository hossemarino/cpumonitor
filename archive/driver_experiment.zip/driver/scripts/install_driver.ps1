param(
    [ValidateSet('Debug','Release')]
    [string]$Config = 'Release'
)

$ErrorActionPreference = 'Stop'

$driverRoot = Split-Path -Parent $PSScriptRoot
$pkgDir = Join-Path $driverRoot ("build\\$Config\\package")

$inf = Join-Path $pkgDir 'ccm_kmdf.inf'
if (!(Test-Path $inf)) {
    throw "INF not found ($inf). Build + make_cat first."
}

Write-Host "Installing driver package via pnputil (admin required)" -ForegroundColor Cyan
& pnputil.exe /add-driver $inf /install

Write-Host "Checking driver service (ccm_kmdf)..." -ForegroundColor Cyan
& sc.exe query ccm_kmdf
if ($LASTEXITCODE -eq 0) {
    Write-Host "Attempting to start driver service (best-effort)..." -ForegroundColor Cyan
    & sc.exe start ccm_kmdf
    & sc.exe query ccm_kmdf
}

Write-Host "Next: run the probe: .\\driver\\build\\Release\\ccm_driver_probe.exe" -ForegroundColor Green
