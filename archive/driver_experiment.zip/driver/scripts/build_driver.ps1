param(
    [ValidateSet('Debug','Release')]
    [string]$Config = 'Release',

    [ValidateSet('x64')]
    [string]$Platform = 'x64',

    # Optional explicit MSBuild path (useful when you know exactly where Build Tools is installed).
    [string]$MSBuildPath = '',

    # Optional explicit VsDevCmd.bat path.
    [string]$VsDevCmdPath = '',

    # Prefer running MSBuild through VsDevCmd so VC/SDK/WDK env vars are set.
    [switch]$UseVsDevCmd
)

$ErrorActionPreference = 'Stop'

# Default UseVsDevCmd to ON unless explicitly set.
if (-not $PSBoundParameters.ContainsKey('UseVsDevCmd')) {
    $UseVsDevCmd = $true
}

$repoRoot = Split-Path -Parent $PSScriptRoot
$projPath = Join-Path $repoRoot 'ccm_kmdf\ccm_kmdf.vcxproj'
$outDir   = Join-Path $repoRoot ('build\' + $Config)

New-Item -ItemType Directory -Force -Path $outDir | Out-Null

function Find-MSBuild {
    if (-not [string]::IsNullOrWhiteSpace($MSBuildPath)) {
        if (Test-Path $MSBuildPath) { return $MSBuildPath }
        throw "MSBuildPath was provided but does not exist: $MSBuildPath"
    }

    # Prefer VS Build Tools 2022 (commonly installed under Program Files (x86)).
    # User-provided canonical path:
    $bt = "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\MSBuild.exe"
    if (Test-Path $bt) { return $bt }

    # Fallback to env-based path just in case.
    $bt = "$env:ProgramFiles(x86)\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\MSBuild.exe"
    if (Test-Path $bt) { return $bt }

    $vswhere = "$env:ProgramFiles(x86)\Microsoft Visual Studio\Installer\vswhere.exe"
    if (Test-Path $vswhere) {
        # If Build Tools are installed, prefer them.
        $found = & $vswhere -latest -products Microsoft.VisualStudio.Product.BuildTools -requires Microsoft.Component.MSBuild -find "MSBuild\\**\\Bin\\MSBuild.exe" 2>$null
        if ($found -and (Test-Path $found)) {
            return $found
        }

        # Otherwise, accept any VS instance.
        $found = & $vswhere -latest -products * -requires Microsoft.Component.MSBuild -find "MSBuild\\**\\Bin\\MSBuild.exe" 2>$null
        if ($found -and (Test-Path $found)) {
            return $found
        }
    }

    $candidates = @(
        "$env:ProgramFiles\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe",
        "$env:ProgramFiles\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\MSBuild.exe",
        "$env:ProgramFiles\Microsoft Visual Studio\2022\Enterprise\MSBuild\Current\Bin\MSBuild.exe",
        "$env:ProgramFiles\Microsoft Visual Studio\2022\BuildTools\MSBuild\Current\Bin\MSBuild.exe"
    )

    foreach ($p in $candidates) {
        if (Test-Path $p) { return $p }
    }

    $msbuild = (Get-Command msbuild.exe -ErrorAction SilentlyContinue)?.Source
    if ($msbuild) { return $msbuild }

    throw "MSBuild not found. Install Visual Studio 2022 (or Build Tools) + 'Desktop development with C++' + Windows SDK + Windows WDK (KMDF)."
}

function Find-VsDevCmd {
    if (-not [string]::IsNullOrWhiteSpace($VsDevCmdPath)) {
        if (Test-Path $VsDevCmdPath) { return $VsDevCmdPath }
        throw "VsDevCmdPath was provided but does not exist: $VsDevCmdPath"
    }

    # Prefer Build Tools 2022.
    $bt = "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat"
    if (Test-Path $bt) { return $bt }

    $bt = "$env:ProgramFiles(x86)\Microsoft Visual Studio\2022\BuildTools\Common7\Tools\VsDevCmd.bat"
    if (Test-Path $bt) { return $bt }

    $vswhere = "$env:ProgramFiles(x86)\Microsoft Visual Studio\Installer\vswhere.exe"
    if (Test-Path $vswhere) {
        $installPath = & $vswhere -latest -products Microsoft.VisualStudio.Product.BuildTools -property installationPath 2>$null
        if ($installPath) {
            $candidate = Join-Path $installPath 'Common7\Tools\VsDevCmd.bat'
            if (Test-Path $candidate) { return $candidate }
        }

        $installPath = & $vswhere -latest -products * -property installationPath 2>$null
        if ($installPath) {
            $candidate = Join-Path $installPath 'Common7\Tools\VsDevCmd.bat'
            if (Test-Path $candidate) { return $candidate }
        }
    }

    return $null
}

$msbuildExe = Find-MSBuild

function Get-LatestKitsIncludeVersion {
    $root = 'C:\Program Files (x86)\Windows Kits\10\Include'
    if (!(Test-Path $root)) { return $null }

    $v = Get-ChildItem -Path $root -Directory -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -match '^\d+\.\d+\.\d+\.\d+$' } |
        Sort-Object Name -Descending |
        Select-Object -First 1
    if ($null -eq $v) { return $null }
    return $v.Name
}

function Assert-WdkPresent {
    $ver = Get-LatestKitsIncludeVersion
    if (-not $ver) {
        throw "Windows Kits include folder not found. Install Windows 10/11 SDK + WDK."
    }

    $ntddk = "C:\Program Files (x86)\Windows Kits\10\Include\$ver\km\ntddk.h"
    if (!(Test-Path $ntddk)) {
        throw "Kernel headers not found ($ntddk). Install the Windows Driver Kit (WDK)."
    }

    # KMDF requires WDF headers.
    # Some installs place WDF headers in a non-versioned path:
    #   C:\Program Files (x86)\Windows Kits\10\Include\wdf\kmdf\<kmdfver>\wdf.h
    $wdfNonVersioned = "C:\Program Files (x86)\Windows Kits\10\Include\wdf\kmdf\1.33\wdf.h"
    $wdfVersioned    = "C:\Program Files (x86)\Windows Kits\10\Include\$ver\wdf\kmdf\1.33\wdf.h"

    if ((Test-Path $wdfNonVersioned) -or (Test-Path $wdfVersioned)) {
        return
    }

    throw "KMDF/WDF headers not found (checked $wdfNonVersioned and $wdfVersioned). Install the Windows Driver Kit (WDK) and ensure VS/BuildTools integration is enabled."
}

Assert-WdkPresent

$sdkVer = Get-LatestKitsIncludeVersion

$msbuildArgs = @(
    $projPath,
    '/m',
    '/t:Build',
    "/p:Configuration=$Config",
    "/p:Platform=$Platform",
    "/p:WindowsTargetPlatformVersion=$sdkVer",
    '/v:minimal'
)

function Quote-CmdArg([string]$arg) {
    if ($null -eq $arg) { return '""' }
    if ($arg -match '[\s"]') {
        return '"' + ($arg -replace '"', '""') + '"'
    }
    return $arg
}

Write-Host "Building driver project: $projPath" -ForegroundColor Cyan

if ($UseVsDevCmd) {
    $vsDevCmd = Find-VsDevCmd
    if (-not $vsDevCmd) {
        Write-Host "VsDevCmd.bat not found; running MSBuild directly." -ForegroundColor Yellow
        & $msbuildExe @msbuildArgs
    } else {
        # Run inside cmd.exe so VsDevCmd can set the environment for MSBuild.
        $msbuildCmd = (Quote-CmdArg $msbuildExe) + ' ' + (($msbuildArgs | ForEach-Object { Quote-CmdArg $_ }) -join ' ')
        $cmdLine = (Quote-CmdArg $vsDevCmd) + ' -no_logo -arch=' + $Platform + ' -host_arch=' + $Platform + ' && ' + $msbuildCmd

        Write-Host "Using VsDevCmd: $vsDevCmd" -ForegroundColor Cyan
        & cmd.exe /c $cmdLine
        if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    }
} else {
    & $msbuildExe @msbuildArgs
}

Write-Host "Build complete. Next: run .\scripts\make_cat.ps1 then .\scripts\sign_driver.ps1" -ForegroundColor Green
