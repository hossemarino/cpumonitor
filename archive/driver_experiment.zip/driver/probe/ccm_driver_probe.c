#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>

#include "../include/ccm_driver_ioctl.h"

static void print_win32_error(const char *what) {
    DWORD err = GetLastError();
    char *msg = NULL;
    FormatMessageA(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        err,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPSTR)&msg,
        0,
        NULL);

    if (msg) {
        fprintf(stderr, "%s: Win32 error %lu: %s\n", what, (unsigned long)err, msg);
        LocalFree(msg);
    } else {
        fprintf(stderr, "%s: Win32 error %lu\n", what, (unsigned long)err);
    }
}

static int query_version(HANDLE h) {
    CCM_DRIVER_VERSION v;
    DWORD bytes = 0;
    BOOL ok = DeviceIoControl(h,
                             (DWORD)CCM_IOCTL_GET_VERSION,
                             NULL,
                             0,
                             &v,
                             (DWORD)sizeof(v),
                             &bytes,
                             NULL);
    if (!ok) {
        print_win32_error("DeviceIoControl(GET_VERSION)");
        return 0;
    }
    if (bytes < sizeof(v)) {
        fprintf(stderr, "GET_VERSION returned short buffer: %lu bytes\n", (unsigned long)bytes);
        return 0;
    }

    printf("Driver version: %u.%u.%u  (ABI %u)\n", v.major, v.minor, v.patch, v.abi);
    return 1;
}

static int query_caps(HANDLE h) {
    CCM_DRIVER_CAPS c;
    DWORD bytes = 0;
    BOOL ok = DeviceIoControl(h,
                             (DWORD)CCM_IOCTL_GET_CAPS,
                             NULL,
                             0,
                             &c,
                             (DWORD)sizeof(c),
                             &bytes,
                             NULL);
    if (!ok) {
        print_win32_error("DeviceIoControl(GET_CAPS)");
        return 0;
    }
    if (bytes < sizeof(c)) {
        fprintf(stderr, "GET_CAPS returned short buffer: %lu bytes\n", (unsigned long)bytes);
        return 0;
    }

    printf("Capabilities: 0x%08X\n", (unsigned)c.capabilityBits);
    if (c.capabilityBits == 0) {
        printf("  (none)\n");
    } else {
        if (c.capabilityBits & CCM_CAP_RDMSR_ALLOWLIST) printf("  - RDMSR allow-list\n");
        if (c.capabilityBits & CCM_CAP_PCI_CFG_READ)    printf("  - PCI config read\n");
        if (c.capabilityBits & CCM_CAP_ACPI_EC_READ)    printf("  - ACPI/EC read broker\n");
    }
    return 1;
}

int main(void) {
    printf("CCM driver probe\n");
    printf("Opening %s\n", CCM_DRIVER_DOS_DEVICE_NAME_A);

    HANDLE h = CreateFileA(CCM_DRIVER_DOS_DEVICE_NAME_A,
                           GENERIC_READ,
                           FILE_SHARE_READ | FILE_SHARE_WRITE,
                           NULL,
                           OPEN_EXISTING,
                           FILE_ATTRIBUTE_NORMAL,
                           NULL);

    if (h == INVALID_HANDLE_VALUE) {
        DWORD err = GetLastError();
        print_win32_error("CreateFile(\\\\.\\CCMTelemetry)");
        fprintf(stderr, "\nNext checks:\n");
        if (err == ERROR_FILE_NOT_FOUND) {
            fprintf(stderr, "- The device link is missing. The driver likely isn't started/loaded yet.\n");
            fprintf(stderr, "  Try: sc.exe query ccm_kmdf  (and sc.exe start ccm_kmdf)\n");
            fprintf(stderr, "  If installed via PnP root driver, a reboot may be required after first install.\n");
        } else if (err == ERROR_ACCESS_DENIED) {
            fprintf(stderr, "- Access denied: the device ACL allows SYSTEM/Admin only. Run from an elevated shell.\n");
        } else {
            fprintf(stderr, "- Verify the service exists: sc.exe query ccm_kmdf\n");
        }
        return 2;
    }

    int ok = 1;
    ok &= query_version(h);
    ok &= query_caps(h);

    CloseHandle(h);
    return ok ? 0 : 1;
}
