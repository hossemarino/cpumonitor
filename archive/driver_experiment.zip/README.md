# Archived: driver experiment

This folder contains the previously-scaffolded KMDF driver experiment (build/sign scripts, probe tool, and headers).

It is archived to keep the main CCM project small and driver-free.

The **documentation remains** in `help/` and is included in `help/CCM.chm`:
- `help/drivers_and_privileges.html`
- `help/driver_mode_roadmap_amd.html`
- `help/driver_threat_model.html`

If driver work is resumed later, move the archived code back into an active `driver/` folder and re-validate:
- WDK/SDK/Build Tools prerequisites
- signing workflow
- threat model + IOCTL allow-lists
